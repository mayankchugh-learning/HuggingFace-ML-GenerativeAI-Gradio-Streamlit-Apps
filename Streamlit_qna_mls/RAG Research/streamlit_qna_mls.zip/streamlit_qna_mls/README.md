---
title: Streamlit Documentation Qna Chroma Anyscale
emoji: ⚡
colorFrom: yellow
colorTo: blue
sdk: gradio
sdk_version: 4.29.0
app_file: app.py
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
